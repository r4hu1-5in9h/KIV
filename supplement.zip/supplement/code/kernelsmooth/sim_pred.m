function y_vis = sim_pred(design,N)
%simulate Newey Powell problem, return y_vis for kernelsmooth

% simulate data for this design
[f,sim,x_vis,~]=get_design(design);
[x,y,z]=sim(f,N);

csvwrite('df_in.csv',[x y z]);
csvwrite('df_vis.csv',x_vis);

%run R
bash_script = fullfile(pwd,'kernelsmoothIV_pred.sh'); 
system(bash_script);
y_vis=csvread('df_out.csv',1,1);

end

