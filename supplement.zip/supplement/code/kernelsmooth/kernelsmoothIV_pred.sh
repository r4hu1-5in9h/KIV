#!/bin/bash 
export PATH=$PATH:/Library/Frameworks/R.framework/Resources/bin/
Rscript kernelsmoothIV_pred.R