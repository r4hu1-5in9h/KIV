function y_vis = sim_pred(design,N)
%simulate Newey Powell problem, return y_vis for sieve IV with ridge

% simulate data for this design
[f,sim,x_vis,~]=get_design(design);
[x,y,z]=sim(f,N);
df=get_basis(x,y,z,x_vis);

% evaluate on full sample using tuned hyperparameters
y_vis=sieveIV_pred(df,[0,0],3); %exp to ensure pos

end

