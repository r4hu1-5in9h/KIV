#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_deepiv
----------------------------------

Tests for `deepiv` module.
"""


import sys
import unittest

from deepiv import deepiv



class TestDeepiv(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000_something(self):
        pass
