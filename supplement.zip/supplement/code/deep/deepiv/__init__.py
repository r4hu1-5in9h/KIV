# -*- coding: utf-8 -*-

__author__ = """Jason Hartford"""
__email__ = 'jasonhar@cs.ubc.ca'
__version__ = '0.1.0'
