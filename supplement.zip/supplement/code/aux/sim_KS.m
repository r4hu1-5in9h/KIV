function [x,y,z] = sim_KS(f,N)
%SIM_IV generates a data set of size N with according to Newey Powell, with
%structural function f

% simulate (z,x,e)
MU=zeros(4,1);

SIGMA=[1,0,0,0;
       0,1,0,0;
       0,0,1,0;
       0,0,0,1];

r = mvnrnd(MU,SIGMA,N);
c=r(:,1);
z=r(:,2);
eX=r(:,3);
eY=r(:,4);

% simulate x
x=0.5.*z+3.*c+eX;

% simulate y from f
y=f(x)-6.*c+eY;

end

