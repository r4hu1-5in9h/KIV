function test
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

disp('works');

end

