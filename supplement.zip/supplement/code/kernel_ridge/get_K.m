function df=get_K(x,y,z,x_vis)

%precalculate all kernel matrices needed in algorithm

[x1, x2, y1, y2, ~, ~]=split(x,y,z,.5);
v=median_inter(x);

df.y1=y1;
df.y2=y2;
df.y=y;

df.K11=get_K_matrix(x1,x1,v);
df.K22=get_K_matrix(x2,x2,v);
df.K12=get_K_matrix(x1,x2,v);
df.Kaa=get_K_matrix(x,x,v);
df.Kta=get_K_matrix(x_vis,x,v);

end

