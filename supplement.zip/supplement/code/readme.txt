master.m runs all experiments

for each algorithm a in {deep,kernel_ridge,kernelsmooth,KIV,sieve,sieve_ridge}:
folder a corresponds to the linear and sigmoid designs
folder a2 corresponds to the demand design

within each folder, main.m runs 1 simulation

kernel_ridge relies on the R function npregiv in the package np
deep relies on Keras 2.0.6. Follow installation instructions here: https://github.com/jhartford/DeepIV

a user needs to supply their own Keras 2.0.6 virtual env location in the following scripts
deep/deepIV_pred.py
deep2/deepIV_pred.py

a user needs to supply their own R location in the following scripts
kernelsmooth/kernelsmoothIV_pred.sh
kernelsmooth2/kernelsmoothIV_pred.sh

the robustness study is in KIV_robustness
